import { Router, Request, Response, NextFunction } from "express";
import multer from "multer";
import { parseCSV } from "../utils/csvParser";
import { evaluateCandidates } from "../services/geminiService";
import { AnalysisResult } from "../models/AnalysisResult";
import { AnalyzeRequest } from "../types";
import { createError } from "../middleware/errorHandler";

const router = Router();

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB limit
  fileFilter: (_req, file, cb) => {
    if (
      file.mimetype === "text/csv" ||
      file.mimetype === "application/vnd.ms-excel" ||
      file.originalname.endsWith(".csv")
    ) {
      cb(null, true);
    } else {
      cb(new Error("Only CSV files are allowed"));
    }
  },
});

// POST /api/analyze - Main analysis endpoint
router.post(
  "/",
  upload.single("csvFile"),
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      // Parse job from body
      let job: AnalyzeRequest["job"];
      try {
        const jobData =
          typeof req.body.job === "string"
            ? JSON.parse(req.body.job)
            : req.body.job;

        if (!jobData?.title) {
          throw createError("Job title is required", 400);
        }
        if (!jobData?.skills || !Array.isArray(jobData.skills)) {
          throw createError("Job skills must be an array", 400);
        }

        job = {
          title: jobData.title,
          skills: jobData.skills,
          experienceYears: Number(jobData.experienceYears) || 0,
          description: jobData.description || "",
        };
      } catch (e) {
        if ((e as any).isOperational) throw e;
        throw createError("Invalid job data format", 400);
      }

      // Parse candidates from CSV
      if (!req.file) {
        throw createError("CSV file is required", 400);
      }

      const csvContent = req.file.buffer.toString("utf-8");
      let candidates;
      try {
        candidates = parseCSV(csvContent);
      } catch (e) {
        throw createError(`CSV parsing error: ${(e as Error).message}`, 400);
      }

      if (candidates.length === 0) {
        throw createError("No candidates found in CSV", 400);
      }

      if (candidates.length > 100) {
        throw createError("Maximum 100 candidates allowed per analysis", 400);
      }

      // Call Gemini AI
      let results;
      try {
        results = await evaluateCandidates(job, candidates);
      } catch (e) {
        const msg = (e as Error).message;
        if (msg.includes("API key")) {
          throw createError("Gemini API key is invalid or missing", 500);
        }
        throw createError(`AI evaluation failed: ${msg}`, 500);
      }

      // Save to MongoDB
      let savedAnalysis;
      try {
        savedAnalysis = await AnalysisResult.create({
          jobTitle: job.title,
          jobSkills: job.skills,
          jobExperience: job.experienceYears,
          jobDescription: job.description,
          totalCandidates: candidates.length,
          results,
          analyzedAt: new Date(),
        });
      } catch (e) {
        // MongoDB save failure shouldn't block the response
        console.error("MongoDB save error:", e);
      }

      res.json({
        success: true,
        data: {
          jobId: savedAnalysis?._id?.toString() || "unsaved",
          jobTitle: job.title,
          totalCandidates: candidates.length,
          analyzedAt: new Date().toISOString(),
          results,
        },
      });
    } catch (err) {
      next(err);
    }
  }
);

// GET /api/analyze/:id - Retrieve saved analysis
router.get("/:id", async (req: Request, res: Response, next: NextFunction) => {
  try {
    const analysis = await AnalysisResult.findById(req.params.id);
    if (!analysis) {
      throw createError("Analysis not found", 404);
    }
    res.json({ success: true, data: analysis });
  } catch (err) {
    next(err);
  }
});

// GET /api/analyze - List recent analyses
router.get("/", async (_req: Request, res: Response, next: NextFunction) => {
  try {
    const analyses = await AnalysisResult.find()
      .sort({ analyzedAt: -1 })
      .limit(20)
      .select("jobTitle totalCandidates analyzedAt _id");
    res.json({ success: true, data: analyses });
  } catch (err) {
    next(err);
  }
});

export default router;
