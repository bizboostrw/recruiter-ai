import axios from "axios";
import { Candidate, EvaluatedCandidate, JobRequirements } from "../types";

const GEMINI_API_URL =
  "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent";

function buildPrompt(job: JobRequirements, candidates: Candidate[]): string {
  const jobDescription = `
Job Title: ${job.title}
Required Skills: ${job.skills.join(", ")}
Required Experience: ${job.experienceYears} years
${job.description ? `Additional Requirements: ${job.description}` : ""}
  `.trim();

  const candidateList = candidates
    .map((c, i) => {
      const skills = Array.isArray(c.skills)
        ? c.skills.join(", ")
        : c.skills;

      return `
Candidate ${i + 1}:
  Name: ${c.name}
  Skills: ${skills}
  Experience: ${c.experience}
  Education: ${c.education}
  ${Object.entries(c)
    .filter(([k]) => !["name", "skills", "experience", "education"].includes(k))
    .map(([k, v]) => `  ${k}: ${v}`)
    .join("\n")}
`;
    })
    .join("\n---\n");

  return `You are an expert technical recruiter with 15+ years of hiring experience.

JOB REQUIREMENTS:
${jobDescription}

CANDIDATES TO EVALUATE:
${candidateList}

INSTRUCTIONS:
- Evaluate every candidate against the job requirements
- Score each candidate from 0 to 100
- Rank all candidates from highest to lowest
- Return top 10 candidates (or all if fewer)
- Be precise and consistent

For each candidate return:
- name
- score
- rank
- strengths (2-4)
- weaknesses (1-3)
- explanation (2-3 sentences)
- recommendation (Yes/Maybe/No)
- whyNotSelected (ONLY if No)

RETURN STRICT JSON ONLY:

{
  "candidates": [
    {
      "name": "string",
      "score": number,
      "rank": number,
      "strengths": ["string"],
      "weaknesses": ["string"],
      "explanation": "string",
      "recommendation": "Yes" | "Maybe" | "No",
      "whyNotSelected": "string"
    }
  ]
}`;
}

async function callGemini(prompt: string, apiKey: string) {
  return axios.post(
    GEMINI_API_URL,
    {
      contents: [
        {
          parts: [{ text: prompt }],
        },
      ],
      generationConfig: {
        temperature: 0.2,
        maxOutputTokens: 4096,
      },
    },
    {
      headers: {
        "Content-Type": "application/json",
      },
      params: {
        key: apiKey,
      },
      timeout: 60000,
    }
  );
}

export async function evaluateCandidates(
  job: JobRequirements,
  candidates: Candidate[]
): Promise<EvaluatedCandidate[]> {
  const apiKey = process.env.GEMINI_API_KEY;

  if (!apiKey) {
    throw new Error("GEMINI_API_KEY is not configured");
  }

  const prompt = buildPrompt(job, candidates);

  let response;

  try {
    response = await callGemini(prompt, apiKey);
  } catch (error: any) {
    console.error("⚠️ Gemini Flash failed:", error.response?.data || error.message);

    // 🔁 fallback model
    try {
      console.log("🔁 Trying fallback model...");
      response = await axios.post(
        "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-pro:generateContent",
        {
          contents: [{ parts: [{ text: prompt }] }],
        },
        {
          params: { key: apiKey },
        }
      );
    } catch (fallbackError: any) {
      console.error(
        "❌ Gemini fallback failed:",
        fallbackError.response?.data || fallbackError.message
      );
      throw new Error("AI evaluation failed completely");
    }
  }

  const rawText: string =
    response.data?.candidates?.[0]?.content?.parts?.[0]?.text;

  if (!rawText) {
    console.error("❌ Empty Gemini response:", response.data);
    throw new Error("No response from Gemini API");
  }

  // Clean markdown if any
  const cleaned = rawText
    .replace(/```json\s*/gi, "")
    .replace(/```\s*/gi, "")
    .trim();

  let parsed: { candidates: EvaluatedCandidate[] };

  try {
    parsed = JSON.parse(cleaned);
  } catch (err) {
    console.error("❌ JSON Parse Error. Raw output:", cleaned);
    throw new Error("Failed to parse Gemini response");
  }

  if (!parsed.candidates || !Array.isArray(parsed.candidates)) {
    console.error("❌ Invalid structure:", parsed);
    throw new Error("Gemini response missing candidates array");
  }

  // Normalize results
  const sorted = parsed.candidates
    .sort((a, b) => b.score - a.score)
    .map((c, i) => ({
      ...c,
      rank: i + 1,
      score: Math.max(0, Math.min(100, Math.round(c.score))),
    }));

  return sorted;
}